# Customer Churn Analysis

A beginner-friendly Python project for analyzing customer churn and predicting which customers may leave a subscription service.

## Project contents
- `customer_churn_analysis.py` — complete analysis, visualizations, and optional machine-learning model.
- `requirements.txt` — required Python packages.
- `sample_customer_churn.csv` — small sample dataset so the project runs immediately.
- `CODTECH_Project_Report.md` — report template you can adapt for submission.

## Run the project
1. Install Python 3.10 or newer.
2. Open a terminal in this folder.
3. Install packages:
   ```bash
   pip install -r requirements.txt
   ```
4. Run:
   ```bash
   python customer_churn_analysis.py
   ```
5. Outputs are saved to the `outputs/` folder.

## Use a real dataset
The script looks for `customer_churn.csv` in the project folder first. If it is not present, it uses `sample_customer_churn.csv`.
For a real dataset, provide columns similar to:
- `tenure` (months with company)
- `MonthlyCharges`
- `TotalCharges` (optional)
- `Contract` (optional)
- `InternetService` (optional)
- `PaymentMethod` (optional)
- `Churn` (target; values such as Yes/No or 1/0)

The script automatically handles available columns and prints which columns it used.

## Important
The included CSV is synthetic sample data created for demonstration, not real customer records. Mention the dataset source accurately in your final report. If CODTECH provided a specific dataset or required format, use that instead.
