"""
Customer Churn Analysis
Run: python customer_churn_analysis.py

Loads customer_churn.csv when available; otherwise uses the included
synthetic sample_customer_churn.csv. Saves charts and metrics in outputs/.
"""
from pathlib import Path
import warnings

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.metrics import (
    accuracy_score, classification_report, confusion_matrix,
    precision_score, recall_score, f1_score, roc_auc_score
)
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.ensemble import RandomForestClassifier

warnings.filterwarnings("ignore", category=FutureWarning)
ROOT = Path(__file__).resolve().parent
OUTPUT = ROOT / "outputs"
OUTPUT.mkdir(exist_ok=True)
sns.set_theme(style="whitegrid")


def load_data():
    real_path = ROOT / "customer_churn.csv"
    sample_path = ROOT / "sample_customer_churn.csv"
    path = real_path if real_path.exists() else sample_path
    data = pd.read_csv(path)
    print(f"Loaded dataset: {path.name}")
    return data


def find_target(df):
    for col in df.columns:
        if col.strip().lower() in {"churn", "exited", "customer_churn"}:
            return col
    raise ValueError("Could not find a target column named Churn, Exited, or Customer_Churn.")


def normalize_target(series):
    """Convert common Yes/No, True/False, and 1/0 labels to 1/0."""
    if pd.api.types.is_numeric_dtype(series):
        vals = set(series.dropna().unique())
        if vals.issubset({0, 1}):
            return series.astype("Int64")
    mapping = {
        "yes": 1, "y": 1, "true": 1, "1": 1, "churned": 1,
        "no": 0, "n": 0, "false": 0, "0": 0, "stayed": 0,
    }
    normalized = series.astype(str).str.strip().str.lower().map(mapping)
    if normalized.isna().any():
        raise ValueError(
            "Target values must be Yes/No, True/False, or 1/0. "
            f"Found values: {series.dropna().unique()[:10]}"
        )
    return normalized.astype(int)


def save_charts(df, target_col, y):
    # Churn distribution
    counts = y.map({0: "Stayed", 1: "Churned"}).value_counts().reindex(
        ["Stayed", "Churned"], fill_value=0
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    sns.barplot(x=counts.index, y=counts.values, ax=ax)
    ax.set_title("Customer Churn Distribution")
    ax.set_xlabel("Customer status")
    ax.set_ylabel("Number of customers")
    for container in ax.containers:
        ax.bar_label(container)
    fig.tight_layout()
    fig.savefig(OUTPUT / "churn_distribution.png", dpi=160)
    plt.close(fig)

    # Numeric feature comparisons, when numeric features exist
    numeric = df.drop(columns=[target_col], errors="ignore").select_dtypes(include=np.number)
    numeric = numeric.drop(columns=[c for c in numeric.columns if c.lower() in {"customerid", "customer_id", "id"}], errors="ignore")
    if not numeric.empty:
        plot_df = numeric.copy()
        plot_df["Churn status"] = y.map({0: "Stayed", 1: "Churned"}).values
        candidates = [c for c in ["tenure", "MonthlyCharges", "TotalCharges", "SeniorCitizen"] if c in numeric.columns]
        if not candidates:
            candidates = list(numeric.columns[:min(4, len(numeric.columns))])
        fig, axes = plt.subplots(len(candidates), 1, figsize=(8, 4 * len(candidates)))
        if len(candidates) == 1:
            axes = [axes]
        for ax, col in zip(axes, candidates):
            sns.boxplot(data=plot_df, x="Churn status", y=col, ax=ax)
            ax.set_title(f"{col} by churn status")
        fig.tight_layout()
        fig.savefig(OUTPUT / "numeric_features_by_churn.png", dpi=160)
        plt.close(fig)

    # Correlation heatmap for numeric columns including churn
    corr_df = numeric.copy()
    corr_df["Churn (1=yes)"] = y.values
    if corr_df.shape[1] >= 2:
        fig, ax = plt.subplots(figsize=(9, 6))
        sns.heatmap(corr_df.corr(numeric_only=True), annot=True, cmap="coolwarm", fmt=".2f", ax=ax)
        ax.set_title("Numeric Feature Correlation")
        fig.tight_layout()
        fig.savefig(OUTPUT / "correlation_heatmap.png", dpi=160)
        plt.close(fig)


def train_model(df, target_col, y):
    X = df.drop(columns=[target_col]).copy()
    # Remove common identifiers because they are not meaningful predictors.
    X = X.drop(columns=[c for c in X.columns if c.strip().lower() in {"customerid", "customer_id", "id"}], errors="ignore")
    # Convert object columns to consistent strings and blank strings to missing values.
    for col in X.select_dtypes(include=["object"]).columns:
        X[col] = X[col].replace(r"^\s*$", np.nan, regex=True)

    if X.shape[1] == 0:
        print("No predictor columns available; skipping model.")
        return

    numeric_cols = list(X.select_dtypes(include=np.number).columns)
    categorical_cols = [c for c in X.columns if c not in numeric_cols]
    transformers = []
    if numeric_cols:
        transformers.append(("numeric", Pipeline([
            ("imputer", SimpleImputer(strategy="median")),
            ("scaler", StandardScaler()),
        ]), numeric_cols))
    if categorical_cols:
        transformers.append(("categorical", Pipeline([
            ("imputer", SimpleImputer(strategy="most_frequent")),
            ("onehot", OneHotEncoder(handle_unknown="ignore")),
        ]), categorical_cols))

    preprocessor = ColumnTransformer(transformers=transformers)
    model = Pipeline([
        ("preprocessor", preprocessor),
        ("classifier", RandomForestClassifier(
            n_estimators=200, random_state=42, class_weight="balanced"
        )),
    ])

    if y.nunique() < 2 or y.value_counts().min() < 2:
        print("Not enough examples in each class for a stratified train/test split; skipping model.")
        return

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=42, stratify=y
    )
    model.fit(X_train, y_train)
    pred = model.predict(X_test)
    proba = model.predict_proba(X_test)[:, 1]

    metrics = {
        "Accuracy": accuracy_score(y_test, pred),
        "Precision": precision_score(y_test, pred, zero_division=0),
        "Recall": recall_score(y_test, pred, zero_division=0),
        "F1 score": f1_score(y_test, pred, zero_division=0),
    }
    try:
        metrics["ROC-AUC"] = roc_auc_score(y_test, proba)
    except ValueError:
        metrics["ROC-AUC"] = float("nan")

    with open(OUTPUT / "model_metrics.txt", "w", encoding="utf-8") as f:
        f.write("Customer Churn Prediction - Test Set Metrics\n")
        f.write("=" * 45 + "\n")
        for key, value in metrics.items():
            f.write(f"{key}: {value:.3f}\n")
        f.write("\nClassification report:\n")
        f.write(classification_report(y_test, pred, zero_division=0))
    print("\nModel evaluation:")
    for key, value in metrics.items():
        print(f"{key}: {value:.3f}")
    print("\nClassification report:\n", classification_report(y_test, pred, zero_division=0))

    cm = confusion_matrix(y_test, pred, labels=[0, 1])
    fig, ax = plt.subplots(figsize=(6, 5))
    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues",
                xticklabels=["Stayed", "Churned"],
                yticklabels=["Stayed", "Churned"], ax=ax)
    ax.set_title("Confusion Matrix")
    ax.set_xlabel("Predicted")
    ax.set_ylabel("Actual")
    fig.tight_layout()
    fig.savefig(OUTPUT / "confusion_matrix.png", dpi=160)
    plt.close(fig)

    # Feature importance after preprocessing
    try:
        names = model.named_steps["preprocessor"].get_feature_names_out()
        importances = model.named_steps["classifier"].feature_importances_
        imp = pd.DataFrame({"Feature": names, "Importance": importances})
        imp = imp.sort_values("Importance", ascending=False).head(15)
        fig, ax = plt.subplots(figsize=(9, 6))
        sns.barplot(data=imp, x="Importance", y="Feature", ax=ax)
        ax.set_title("Top 15 Feature Importances")
        fig.tight_layout()
        fig.savefig(OUTPUT / "feature_importance.png", dpi=160)
        plt.close(fig)
        imp.to_csv(OUTPUT / "feature_importance.csv", index=False)
    except Exception as exc:
        print(f"Feature-importance chart skipped: {exc}")


def main():
    df = load_data()
    df.columns = [c.strip() for c in df.columns]
    target_col = find_target(df)
    df = df.dropna(subset=[target_col]).copy()
    y = normalize_target(df[target_col])
    df = df.reset_index(drop=True)
    y = y.reset_index(drop=True)

    print("\nDataset preview:")
    print(df.head().to_string(index=False))
    print(f"\nRows: {len(df)} | Columns: {len(df.columns)}")
    print("\nMissing values by column:")
    print(df.isna().sum().to_string())
    print(f"\nOverall churn rate: {y.mean() * 100:.2f}%")

    summary = pd.DataFrame({
        "Metric": ["Total customers", "Churned customers", "Customers retained", "Churn rate (%)"],
        "Value": [len(y), int((y == 1).sum()), int((y == 0).sum()), round(y.mean() * 100, 2)],
    })
    summary.to_csv(OUTPUT / "summary_statistics.csv", index=False)
    save_charts(df, target_col, y)
    train_model(df, target_col, y)

    print(f"\nAnalysis complete. Results saved in: {OUTPUT}")
    print("Charts: churn_distribution.png, numeric_features_by_churn.png (if numeric data),")
    print("correlation_heatmap.png (if possible), confusion_matrix.png, feature_importance.png.")


if __name__ == "__main__":
    main()
